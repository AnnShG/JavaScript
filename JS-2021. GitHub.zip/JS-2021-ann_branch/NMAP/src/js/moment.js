var moment = require("moment");

var today = new Date();
export var todayFormatted = moment(today).format("LL");