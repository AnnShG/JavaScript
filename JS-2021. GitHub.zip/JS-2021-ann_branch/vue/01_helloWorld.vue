//template block should return single DOM node
//npm run vue -- serve -- 01_helloWorld.vue
<template>
    <div>
    <span>Hello World!</span>
    <span>Hey There!</span>
    </div>
</template>

<script>
export default {
    //
    data() {
        return {};
    }
}
</script>

<style>
body {
    background: #2e2e2e;
    color: #f9f9f9;
}
</style>