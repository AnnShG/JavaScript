const students = require("./students");
const grades = require("./grades");

module.exports = {
    students,
    grades,
};