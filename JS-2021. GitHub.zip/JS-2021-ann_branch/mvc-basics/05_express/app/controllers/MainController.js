function MainController (req, res) {
    
}

module.exports = MainController;